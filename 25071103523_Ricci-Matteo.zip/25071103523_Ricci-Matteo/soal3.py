katalog = [ {'merk': 'Samsung', 'tipe': 'S23', 'sn': 'SAM01', 'stok': 2}, 
           {'merk': 'Oppo', 'tipe': 'Reno 10', 'sn': 'OPP01', 'stok': 5} ]
def update_stok(katalog, sn_target, jumlah_tambah):
  for i in range(len(katalog)):
    if sn_target == katalog[i]['sn']:
      katalog[i]['stok'] = katalog[i]['stok'] + 1

daftar_merk = {}
for i in range(len(katalog)):
  daftar_merk.update(katalog[i]['merk'])